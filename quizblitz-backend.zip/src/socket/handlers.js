const { getDb } = require('../utils/firebase');

function registerSocketHandlers(io) {
  io.on('connection', (socket) => {
    socket.on('join_game', async ({ sessionId, name }) => {
      const db = getDb();
      const ref = db.collection('sessions').doc(sessionId);
      const snap = await ref.get();

      if (!snap.exists) return;

      const player = {
        id: socket.id,
        name,
        score: 0
      };

      await ref.update({
        [`players.${socket.id}`]: player
      });

      socket.join(sessionId);
      io.to(sessionId).emit('player_joined', player);
    });
  });
}

module.exports = { registerSocketHandlers };