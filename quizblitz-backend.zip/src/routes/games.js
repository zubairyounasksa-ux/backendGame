const router = require('express').Router();
const { v4: uuid } = require('uuid');
const { getDb } = require('../utils/firebase');
const { generatePin } = require('../utils/pinGenerator');

router.post('/', async (req, res) => {
  try {
    const { title, questions } = req.body;

    if (!title || !questions?.length) {
      return res.status(400).json({ error: 'Invalid data' });
    }

    const db = getDb();
    const gameId = uuid();

    await db.collection('games').doc(gameId).set({
      id: gameId,
      title,
      questions,
      createdAt: Date.now(),
    });

    const sessionId = uuid();
    const pin = await generatePin();

    await db.collection('sessions').doc(sessionId).set({
      id: sessionId,
      gameId,
      pin,
      status: 'lobby',
      players: {},
      createdAt: Date.now(),
    });

    res.json({ gameId, sessionId, pin });

  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;