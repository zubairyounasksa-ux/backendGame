const { getDb } = require('./firebase');

async function generatePin() {
  const db = getDb();

  while (true) {
    const pin = Math.floor(100000 + Math.random() * 900000).toString();

    const snap = await db
      .collection('sessions')
      .where('pin', '==', pin)
      .where('status', '==', 'lobby')
      .get();

    if (snap.empty) return pin;
  }
}

module.exports = { generatePin };