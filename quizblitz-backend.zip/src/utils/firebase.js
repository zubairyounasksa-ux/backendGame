const admin = require('firebase-admin');

let db;

function initFirebase() {
  if (admin.apps.length) return;

  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    }),
  });

  db = admin.firestore();
}

function getDb() {
  if (!db) throw new Error('DB not initialized');
  return db;
}

module.exports = { initFirebase, getDb };