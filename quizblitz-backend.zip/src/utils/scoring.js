const BASE_POINTS = 1000;
const SPEED_BONUS = 500;

function calculateScore(correct, remaining, total) {
  if (!correct) return 0;
  const ratio = Math.max(0, remaining / total);
  return BASE_POINTS + Math.floor(SPEED_BONUS * ratio);
}

module.exports = { calculateScore };